package com.example.inthujan.finalproject;

public class RatingDetail {
    public String ratingNumber;

    public RatingDetail(String ratingNumber) {
        this.ratingNumber = ratingNumber;
    }

}
