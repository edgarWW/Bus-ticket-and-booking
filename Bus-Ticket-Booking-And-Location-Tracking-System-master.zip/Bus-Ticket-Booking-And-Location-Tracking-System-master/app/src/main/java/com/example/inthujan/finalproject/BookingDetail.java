package com.example.inthujan.finalproject;

public class BookingDetail {

    public String from;
    public String to;
    public String date;


    public BookingDetail(String from, String to, String date) {
        this.from = from;
        this.to = to;
        this.date = date;
    }

    public BookingDetail(){

    }
}
